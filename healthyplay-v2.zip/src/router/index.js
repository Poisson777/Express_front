import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../components/Login.vue'
import Home from '../components/Home.vue'
import Stu from '../components/Stu.vue'
import Welcome from '../components/Welcome.vue'
import UserList from '../components/admin/UserList.vue'
import OrderList from '../components/admin/OrderList'
import IncidentList from '../components/admin/IncidentList'
import Tself from '../components/admin/Tself.vue'
import TeacherList from '../components/admin/TeacherList.vue'
import TorderList from '../components/admin/TorderList.vue'
import UtemList from '../components/admin/UtemList.vue'
import TtemList from '../components/admin/TtemList.vue'
import FangkeList from '../components/admin/FangkeList.vue'
import TodayFangke from '../components/admin/TodayFangke.vue'
import UserListstu from '../components/user/UserListstu.vue'
import Uself from '../components/user/Uself.vue'
import InserIncident from '../components/user/InserIncident'
import InsertOrder from '../components/user/InsertOrder'
import OrderListstu from '../components/user/OrderListstu'
import InsertUtem from '../components/user/InsertUtem.vue'
import TeacherHome from '../components/Teacher.vue'
import InsertTorder from '../components/teacher/InsertTorder.vue'
import Teaself from '../components/teacher/Tself.vue'
import TeaTorderList from '../components/teacher/TeaTorderList.vue'
import InsertTtem from '../components/teacher/InsertTtem.vue'




Vue.use(VueRouter)

const routes = [
  {
    path:"/",
    redirect:"/login"
  },
  {
    path:"/login",
    component:Login
  }, 
  {
    path:"/home",
    component:Home,
    redirect:"/welcome",
    children:[
      {
        path:"/welcome",
        component:Welcome,
      },
      {
        path:"/user",
        component:UserList,
      },
      {
        path:"/order",
        component:OrderList,
      },
      {
        path:"/incident",
        component:IncidentList,
      },
      {
        path:"/tself",
        component:Tself,
      },
      {
        path:"/teacher",
        component:TeacherList,
      },
      {
        path:"/torder",
        component:TorderList,
      },
      {
        path:"/utemlist",
        component:UtemList,
      },
      {
        path:"/ttemlist",
        component:TtemList,
      },
      {
        path:"/fangke",
        component:FangkeList,
      },
      {
        path:"/insertfangke",
        component:TodayFangke,
      },
      
    ]
  }, 
  {
    path:"/stu",
    component:Stu,
    children:[
      {
        path:"/useru",
        component:UserListstu,
      },
      {
        path:"/uself",
        component:Uself,
      },
      {
        path:"/stuorder",
        component:InsertOrder,
      },
      {
        path:"/stuincident",
        component:InserIncident,
      },
      {
        path:"/myorder",
        component:OrderListstu,
      },
      {
        path:"/insertutem",
        component:InsertUtem,
      },

    ]
  }, 
  {
    path:"/teacherhome",
    component:TeacherHome,
    children:[
      {
        path:"/teacheru",
        component:UserListstu,
      },
      {
        path:"/insteaorder",
        component:InsertTorder,
      },
      {
        path:"/teaself",
        component:Teaself,
      },
      {
        path:"/teaorder",
        component:TeaTorderList,
      },
      {
        path:"/insertTtem",
        component:InsertTtem,
      },

    ]
  }, 
]

const router = new VueRouter({
  routes
})

//挂载路由导航守卫
router.beforeEach((to,from,next)=>{
  //to将要访问的路径，from从哪里来，next接着干的事情 next(url)重定向到url上，如果为空，继续访问to的路径
  if(to.path=='/login') return next();
  //获取user
  const userFlag = window.sessionStorage.getItem("user");  //取出会话层的用户
  if(!userFlag){
    return next('/login'); //无值返回登录页
  }
  next();  //符合要求放行


});

export default router

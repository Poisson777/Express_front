<template>
    <div>
        <h3>欢迎使用疫情校园管理系统！！！</h3>
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="less" scoped>

</style>
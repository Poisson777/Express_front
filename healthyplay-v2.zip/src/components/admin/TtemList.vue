<template>
    <div>
        <h3>外出申请列表</h3>
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>教师管理</el-breadcrumb-item>
            <el-breadcrumb-item>体温上报</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 用户列表主体部分 -->
        <el-card>
            <!-- 搜索区域 -->
            <el-row :gutter="25">
                <el-col :span="4">
                    <el-button type="primary" @click="getOrder0">正常体温</el-button>  
                </el-col> 
                <!-- 搜索按钮 -->
                <el-col :span="4">
                    <el-button type="danger" @click="getOrder1">异常体温</el-button>  
                </el-col> 
                <!-- 批量删除按钮 -->
                <el-col :span="4">
                    <el-button type="info" @click="setOrder2">批量删除</el-button>  
                </el-col> 
                             
            </el-row>
            <!-- 绘制表格区 -->
            <el-table :data="userList" border stripe>
                <!-- 索引列 -->
                <el-table-column type="index"></el-table-column>
                <el-table-column label="请假条号" prop="temid"></el-table-column>
                <el-table-column label="学号" prop="id"></el-table-column>
                <el-table-column label="用户名" prop="username"></el-table-column>
                <el-table-column label="体温" prop="temper"></el-table-column>
                <el-table-column label="日期" prop="date"></el-table-column>
                <el-table-column label="异常" prop="state"></el-table-column>
                <!-- <el-table-column label="是否隔离" prop="geli"> -->
                    <!-- 作用域插槽 -->
                    <!-- <template slot-scope="scope">
                        <el-switch v-model="scope.row.geli"></el-switch>
                    </template> -->
                <!-- </el-table-column> -->
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <!-- 修改 -->
                        <el-button type="success"  size="mini" @click="setOrder1(scope.row.temid)">已处理异常</el-button>
                        <!-- 删除 -->
                        <!-- <el-button type="danger"  size="mini" @click="setOrder2(scope.row.temid)">拒绝</el-button> -->
                        <!-- 权限 -->
                    </template>
                </el-table-column>
                <!-- 分页组件 -->
                
            </el-table>
            <!-- <div>
                    <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="queryInfo.pageNums"
                        :page-sizes="[1, 2, 5, 100]"
                        :page-size="queryInfo.pageNums"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total">
                    </el-pagination>
                </div> -->
        </el-card>
    </div>
</template>

<script>
export default {
    created(){
        this.getUserList();
    },

    data(){
        return{
            //查询信息实体
            queryInfo:{
                query:"",
                pageNum:1,
                pageSize:5,
            },
            userList:[], //用户列表
            total:0,  //总记录数
            state:0,
        }
    },

    methods:{
        //获取所有用户
        async getUserList(){
            const {data:res} = await this.$http.get("getAllTtemByState?state="+this.state);
            //console.log(res);
            this.userList=res.data;
            // this.total=res.numbers;
        },
        //最大数
        handleSizeChange(newSize){
            this.queryInfo.pageSize=newSize;
            this.getUserList();
        },
        //pageNum触发动作
        handleCurrentChange(newPage){
            this.queryInfo.pageNum=newPage;;
            this.getUserList();
        },
        getOrder0(){
            this.state=0;
            console.log(0);
            this.getUserList();
        },
        getOrder1(){
            this.state=1;
            console.log(1);
            this.getUserList();
        },
        getOrder2(){
            this.state=2;
            console.log(2);
            this.getUserList();
        },
        async setOrder1(temid){
            const confirmRes = await this.$confirm('此操作将处理异常，是凑继续','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消处理");
            }
            const {data:res} = await this.$http.delete("agreeTtemByTemid?temid="+temid);
            if (res!="success") {
                return this.$message.error("处理失败！！！");
            }
            this.$message.success("已处理！！！");
            this.getUserList();
        },
        async setOrder2(){
            const confirmRes = await this.$confirm('此操作将批量删除正常体温，是凑继续','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消删除");
            }
            const {data:res} = await this.$http.delete("deleteTtemByState?state="+0);
            if (res!="success") {
                return this.$message.error("删除失败！！！");
            }
            this.$message.success("已删除！！！");
            this.getUserList();
        }
    }
}
</script>

<style lang="less" scoped>

.el-breadcrumb{
    margin-bottom: 15px;
    font-size: 12px;
}

</style>
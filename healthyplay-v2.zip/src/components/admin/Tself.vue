<template>
    <div>
        <h3>个人信息</h3>
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>个人信息</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 用户列表主体部分 -->
        <el-card>
            <el-form  ref="editFormRef" label-width="70px">
                <el-form-item label="用户名" prop="username" >
                    <el-input v-model="username" disabled></el-input>
                </el-form-item>
                <el-form-item label="密码" prop="password">
                    <el-input v-model="password" disabled></el-input>
                </el-form-item>
                <el-form-item label="宿舍号" prop="room">
                    <el-input v-model="room" disabled></el-input>
                </el-form-item>
                <el-form-item label="身份" prop="room">
                    <el-input v-model="shenfen" disabled></el-input>
                </el-form-item>
                
                <el-form-item label="隔离房间" prop="geliroom">
                    <el-input v-model="geliroom" disabled></el-input>
                </el-form-item>
                <el-form-item label="是否隔离" prop="room">
                    <el-input v-model="geli" disabled></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog.footer">
                <el-button >取消</el-button>
                <el-button type="primary">确定</el-button>
            </span>
        </el-card>
    </div>
</template>

<script>
export default {
    created(){
        this.username= window.sessionStorage.getItem("username");
        this.password= window.sessionStorage.getItem("password");
        this.geli= window.sessionStorage.getItem("geli");
        this.room= window.sessionStorage.getItem("room");
        this.id=window.sessionStorage.getItem("id");
        this.geliroom=window.sessionStorage.getItem("geliroom");
        this.college=window.sessionStorage.getItem("college");
        this.class1=window.sessionStorage.getItem("class1");
        console.log(this.class1);
    },

    data(){
        return{
            //查询信息实体
            queryInfo:{
                query:"",
                pageNum:1,
                pageSize:500,
            },
            userList:[], //用户列表
            total:0, 
            tself:{}, //总记录数
            shenfen:"辅导员",
            username:"",
            password:"",
            room:"",
            geli:"",
            college:'',
            class1:'',
            geliroom:'',
            id:0,
        }
    },

    methods:{
        //获取所有用户
        async getUserList(){
            const {data:res} = await this.$http.get("alluser",{params:this.queryInfo});
            this.userList=res.data;
            this.total=res.numbers;
        },
        //最大数
        handleSizeChange(newSize){
            this.queryInfo.pageSize=newSize;
            this.getUserList();
        },
        //pageNum触发动作
        handleCurrentChange(newPage){
            this.queryInfo.pageNum=newPage;;
            this.getUserList();
        }
    }
}
</script>

<style lang="less" scoped>

.el-breadcrumb{
    margin-bottom: 15px;
    font-size: 12px;
}

</style>
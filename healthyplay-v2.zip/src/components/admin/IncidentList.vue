<template>
    <div>
        <h3>紧急处理</h3>
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>学生管理</el-breadcrumb-item>
            <el-breadcrumb-item>意外处理</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 用户列表主体部分 -->
        <el-card>
            
            <!-- 绘制表格区 -->
            <el-table :data="userList" border stripe>
                <!-- 索引列 -->
                <el-table-column type="index"></el-table-column>
                <el-table-column label="事件号" prop="iid"></el-table-column>
                <el-table-column label="学号" prop="id"></el-table-column>
                <el-table-column label="用户名" prop="username"></el-table-column>
                <el-table-column label="原因" prop="reason"></el-table-column>
                <el-table-column label="是否处理" prop="state">
                    <!-- 作用域插槽 -->
                    <!-- <template slot-scope="scope">
                        <el-switch v-model="scope.row.geli"></el-switch>
                    </template> -->
                </el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <!-- 修改 -->
                        <el-button type="success"  size="mini" @click="chuli(scope.row.iid)">已处理完毕</el-button>
                        <!-- 删除 -->
                        
                        <!-- 权限 -->
                        
                    </template>
                </el-table-column>
                
                <!-- 分页组件 -->
                
            </el-table>
            
        </el-card>
    </div>
</template>

<script>
export default {
    created(){
        this.getUserList();
    },

    data(){
        return{
            //查询信息实体
            queryInfo:{
                query:"",
                pageNum:1,
                pageSize:5,
            },
            userList:[], //用户列表
            total:0,  //总记录数
            state:0,
        }
    },

    methods:{
        //获取所有用户
        async getUserList(){
            const {data:res} = await this.$http.get("getincidents?state="+this.state);
            this.userList=res.data;
            //console.log(res.data);
        },
        //最大数
        handleSizeChange(newSize){
            this.queryInfo.pageSize=newSize;
            this.getUserList();
        },
        //pageNum触发动作
        handleCurrentChange(newPage){
            this.queryInfo.pageNum=newPage;;
            this.getUserList();
        },
        async chuli(iid){
            const confirmRes = await this.$confirm('是否确定已处理该学生上报','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消删除");
            }
            const {data:res} = await this.$http.delete("refuseByIid?iid="+iid);
            if (res!="success") {
                return this.$message.error("删除失败！！！");
            }
            this.$message.success("已经处理完毕！！！");
            this.getUserList();
        }
    }
}
</script>

<style lang="less" scoped>

.el-breadcrumb{
    margin-bottom: 15px;
    font-size: 12px;
}

</style>
<template>
    <div>
        <h3>访客信息管理</h3>
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>访客管理</el-breadcrumb-item>
            <el-breadcrumb-item>访客信息管理</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 用户列表主体部分 -->
        <el-card>
            <!-- 搜索区域 -->
            <el-row :gutter="25">
                <el-col :span="10">
                    <el-input placeholder="请输入搜索内容" v-model="queryInfo.query" clearable @clear="getUserList">
                        <el-button slot="append" icon="el-icon-search" @click="getUserList"></el-button>
                    </el-input>
                </el-col>
                <!-- 搜索按钮 -->
                <el-col :span="4">
                    <el-button type="primary" @click="addDialogVisible = true">添加用户</el-button>  
                </el-col>              
            </el-row>
            <!-- 绘制表格区 -->
            <el-table :data="userList" border stripe>
                <!-- 索引列 -->
                <el-table-column type="index"></el-table-column>
                <el-table-column label="访客号" prop="id"></el-table-column>
                <el-table-column label="访客名" prop="username"></el-table-column>
                <el-table-column label="手机号" prop="number"></el-table-column>
                <el-table-column label="日期" prop="date"></el-table-column>
                <el-table-column label="原因" prop="reason"></el-table-column>
                <el-table-column label="状态" prop="state"></el-table-column>

                
                
                <!-- 分页组件 -->
                
            </el-table>
            <div>
                    <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="queryInfo.pageNums"
                        :page-sizes="[1, 2, 5, 100]"
                        :page-size="queryInfo.pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total">
                    </el-pagination>
                </div>
        </el-card>

        <!-- 新增用户区域 -->
        <el-dialog title="新增访客" :visible.sync="addDialogVisible" width="50%" @close="addDialogClose">
            <el-form :model="addForm" :rules="addFormRules" ref="addFormRef" label-width="70px">
                <el-form-item label="访客名" prop="username">
                    <el-input v-model="addForm.username"></el-input>
                </el-form-item>
                <el-form-item label="原因" prop="reason">
                    <el-input v-model="addForm.reason"></el-input>
                </el-form-item>
                <el-form-item label="手机号" prop="number">
                    <el-input v-model="addForm.number"></el-input>
                </el-form-item>
                <el-form-item label="来访时间" prop="date">
                    <el-date-picker
                    class="dp1"
                    v-model="addForm.date"
                    type="date"
                    value-format="yyyy-MM-dd"
                    placeholder="选择日期">
                    </el-date-picker>
                </el-form-item>
                
            </el-form>
            <span slot="footer" class="dialog.footer">
                <el-button @click="addDialogVisible = false">取消</el-button>
                <el-button type="primary" @click="addUser">确定</el-button>
            </span>
        </el-dialog>

        <!-- 修改对话框 -->
        <el-dialog title="修改用户" :visible.sync="editDialogVisiable" width="50%" @close="editDialogClose">
            <el-form :model="editForm" :rules="editFormRules" ref="editFormRef" label-width="70px">
                <el-form-item label="用户名" prop="username" >
                    <el-input v-model="editForm.username" disabled></el-input>
                </el-form-item>
                <el-form-item label="密码" prop="password">
                    <el-input v-model="editForm.password"></el-input>
                </el-form-item>
                <el-form-item label="宿舍号" prop="room">
                    <el-input v-model="editForm.room"></el-input>
                </el-form-item>
                <el-form-item label="学院" prop="college">
                    <el-input v-model="editForm.college"></el-input>
                </el-form-item>
                <el-form-item label="班级" prop="class1">
                    <el-input v-model="editForm.class1"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog.footer">
                <el-button @click="editDialogVisiable = false">取消</el-button>
                <el-button type="primary" @click="editUserInfo">确定</el-button>
            </span>
        </el-dialog>

        <!-- 隔离对话框 -->
        <el-dialog title="修改用户" :visible.sync="geliDialogVisiable" width="50%" @close="geliDialogClose">
            <el-form :model="geliForm" :rules="geliFormRules" ref="geliFormRef" label-width="70px">
                <el-form-item label="用户名" prop="username" >
                    <el-input v-model="geliForm.username" disabled></el-input>
                </el-form-item>
                <el-form-item label="密码" prop="password">
                    <el-input v-model="geliForm.password" disabled></el-input>
                </el-form-item>
                <el-form-item label="宿舍号" prop="room">
                    <el-input v-model="geliForm.room" disabled></el-input>
                </el-form-item>
                <el-form-item label="学院" prop="college">
                    <el-input v-model="geliForm.college" disabled></el-input>
                </el-form-item>
                <el-form-item label="班级" prop="class1">
                    <el-input v-model="geliForm.class1" disabled></el-input>
                </el-form-item>
                <el-form-item label="隔离房间" prop="geliroom">
                    <el-input v-model="geliForm.geliroom"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog.footer">
                <el-button @click="geliDialogVisiable = false">取消</el-button>
                <el-button type="primary" @click="geliUserInfo">确定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
export default {
    created(){
        this.getUserList();
        
    },

    data(){
        return{
            //查询信息实体
            queryInfo:{
                query:"",
                pageNum:1,
                pageSize:5,
            },
            userList:[], //用户列表
            total:0,  //总记录数
            date:"",
            addDialogVisible:false, //对话框隐藏显示状态
            //添加表单信息
            addForm:{
                username:'',
                date:'',
                reason:'',
                number:'',

            },
            order:{
                id:0,
                username:"",
                date:"",
                reason:"",
                number:"",
                state:1,
            },
            //修改用户的信息
            editForm:{},
            //隔离用户信息
            geliForm:{},
            //显示隐藏修改用户栏
            editDialogVisiable:false,
            //隔离修改用护栏
            geliDialogVisiable:false,
            //添加表单验证
            addFormRules: {
                username: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                    { min: 5, max: 8, message: '长度在 5 到 8 个字符', trigger: 'blur' }
                ],
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 5, max: 8, message: '长度在 5 到 8 个字符', trigger: 'blur' }
                ],
                room: [
                    { required: true, message: '请输入房间号', trigger: 'blur' },
                    { min: 3, max: 8, message: '长度在 3 到 8 个字符', trigger: 'blur' }
                ],
                number:[
                    { required: true, message: '请输入手机号', trigger: 'blur' },
                    { min: 11, max: 11, message: '请输入正确的手机号', trigger: 'blur' }
                ],
                reason:[
                    { required: true, message: '请输入原因', trigger: 'blur' },
                    
                ],
            },
            //修改表单验证
            editFormRules: {
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 5, max: 8, message: '长度在 5 到 8 个字符', trigger: 'blur' }
                ],
                room: [
                    { required: true, message: '请输入房间号', trigger: 'blur' },
                    { min: 3, max: 8, message: '长度在 3 到 8 个字符', trigger: 'blur' }
                ],
            },
            geliFormRules: {
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 5, max: 8, message: '长度在 5 到 8 个字符', trigger: 'blur' }
                ],
                room: [
                    { required: true, message: '请输入房间号', trigger: 'blur' },
                    { min: 3, max: 8, message: '长度在 3 到 8 个字符', trigger: 'blur' }
                ],
            },
        }
    },

    methods:{
        //获取所有用户
        async getUserList(){
            const {data:res} = await this.$http.get("allfangke",{params:this.queryInfo});
            this.userList=res.data;
            this.total=res.numbers;
        },
        //最大数
        handleSizeChange(newSize){
            this.queryInfo.pageSize=newSize;
            this.getUserList();
        },
        //pageNum触发动作
        handleCurrentChange(newPage){
            this.queryInfo.pageNum=newPage;;
            this.getUserList();
        },
        //监听添加用户
        addDialogClose(){
            this.$refs.addFormRef.resetFields();

        },
        addUser(){
            this.addForm.date=JSON.stringify(this.addForm.date);
            this.$refs.addFormRef.validate(async valid=>{
                if(!valid){
                    return;
                }
                const{data:res}=await this.$http.post("addFangke",this.addForm);
                if(res!="success"){
                    return this.$message.error("操作失败！！！");
                }
                this.$message.success("操作成功！！！");
                this.addDialogVisible=false;
                this.getUserList();
            });
        },
        async deleteUser(id){
            const confirmRes = await this.$confirm('此操作将永久删除用户，是凑继续','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消删除");
            }
            const {data:res} = await this.$http.delete("deleteUser?id="+id);
            if (res!="success") {
                return this.$message.error("删除失败！！！");
            }
            this.$message.success("删除成功！！！");
            this.getUserList();
        },

        async fanzhuan(id){
            const confirmRes = await this.$confirm('此操作将解禁用户，是凑继续','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消");
            }
            const {data:res} = await this.$http.get("fanzhuan?id="+id);
            if (res!="success") {
                return this.$message.error("解禁失败！！！");
            }
            this.$message.success("解禁成功！！！");
            
            this.getUserList();
        },

        //显示和隐藏对话框
        async showEditDialog(id){
            const {data:res} = await this.$http.get("getupdate?id="+id);
            this.editForm=res;//查询用户信息反填到表单中
            
            this.editDialogVisiable=true;

        },
        //显示隔离对话框
        async showGeliDialog(id){
            const {data:res} = await this.$http.get("getupdate?id="+id);
            this.geliForm=res;
            
            this.geliDialogVisiable=true;

        },
        //关闭窗口
        editDialogClose(){
            this.$refs.editFormRef.resetFields();
        },
        //关闭隔离对话框
        geliDialogClose(){
            this.$refs.editFormRef.resetFields();
        },
        //确认修改
        editUserInfo(id){
            this.$refs.editFormRef.validate(async valid =>{
                if (!valid) {
                    return;
                }
                //发起修改请求
                const {data:res}= await this.$http.put("editUser",this.editForm);
                if (res!="success") {
                    return this.$message.error("修改失败！！！");
                }
                this.$message.success("修改成功！！！");
                this.editDialogVisiable=false;
                this.getUserList();
            })
        },
        //确认隔离
        geliUserInfo(){
            this.$refs.geliFormRef.validate(async valid =>{
                if (!valid) {
                    return;
                }
                //发起修改请求
                const {data:res}= await this.$http.put("geliStu",this.geliForm);
                if (res!="success") {
                    return this.$message.error("隔离失败！！！");
                }
                this.$message.success("隔离成功！！！");
                this.geliDialogVisiable=false;
                this.getUserList();
            })
        },

    }
}
</script>

<style lang="less" scoped>

.el-breadcrumb{
    margin-bottom: 15px;
    font-size: 12px;
}

</style>
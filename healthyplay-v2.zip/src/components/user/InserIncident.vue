<template>
    <div>
        <h3>紧急上报</h3>
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>事务处理</el-breadcrumb-item>
            <el-breadcrumb-item>紧急上报</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 用户列表主体部分 -->
        <el-card>
            <el-form  ref="addFormRef" label-width="70px" >
                <el-form-item label="学号" prop="id" >
                    <el-input v-model="incident.id" disabled></el-input>
                </el-form-item>
                <el-form-item label="用户名" prop="username" >
                    <el-input v-model="incident.username" disabled></el-input>
                </el-form-item>
               
                <el-form-item label="宿舍号" prop="room">
                    <el-input v-model="room" disabled></el-input>
                </el-form-item>
                <el-form-item label="身份" prop="shenfen">
                    <el-input v-model="shenfen" disabled></el-input>
                </el-form-item>
                <el-form-item label="学院" prop="college">
                    <el-input v-model="college" disabled></el-input>
                </el-form-item>
                <el-form-item label="班级" prop="class1">
                    <el-input v-model="class1" disabled></el-input>
                </el-form-item>
                
                <el-form-item label="紧急" prop="reason">
                    <el-autocomplete
                    class="inline-input"
                    v-model="incident.reason"
                    :fetch-suggestions="querySearch"
                    placeholder="请输入内容"
                    @select="handleSelect"
                    style="width=100%"
                    ></el-autocomplete>
                </el-form-item>
            </el-form>
            <el-row :gutter="25">
                
                <!-- 搜索按钮 -->
                <el-col :span="4">
                    <el-button type="danger" @click="addUser">紧急上报</el-button>  
                </el-col>              
            </el-row>
        </el-card>
    </div>
</template>

<script>
export default {
    created(){
        this.username= window.sessionStorage.getItem("username");
        this.password= window.sessionStorage.getItem("password");
        this.geli= window.sessionStorage.getItem("geli");
        this.room= window.sessionStorage.getItem("room");
        this.geliroom= window.sessionStorage.getItem("geliroom");
        this.college= window.sessionStorage.getItem("college");
        this.class1= window.sessionStorage.getItem("class1");
        this.id=window.sessionStorage.getItem("id");
        this.incident.id=this.id;
        this.incident.username=this.username;
        //console.log(this.username);
    },

    data(){
        return{
            //查询信息实体
            queryInfo:{
                query:"",
                pageNum:1,
                pageSize:500,
            },
            restaurants: [],
            userList:[], //用户列表
            total:0, 
            tself:{}, //总记录数
            shenfen:"学生",
            username:"",
            password:"",
            room:"",
            geliroom:"",
            college:"",
            class1:"",
            geli:"",
            id:0,
            incident:{
                username:"",
                id:0,
                reason:"",
                state:0
            },
            state1: '',
            addFormRules: {
                reason: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                ],
            }
        }
    },

    methods:{
        //获取所有用户
        async getUserList(){
            const {data:res} = await this.$http.get("alluser",{params:this.queryInfo});
            this.userList=res.data;
            this.total=res.numbers;
        },
        //最大数
        handleSizeChange(newSize){
            this.queryInfo.pageSize=newSize;
            this.getUserList();
        },
        //pageNum触发动作
        handleCurrentChange(newPage){
            this.queryInfo.pageNum=newPage;;
            this.getUserList();
        },
        insertOrder(){
            console.log(this.incident.reason);
        },
        async addUser(){
            if(this.incident.reason==""){
                this.$message.error("上报失败");
                return;
            }
            const{data:res}=await this.$http.post("addIncidents",this.incident);
            if (res=="success") {
                this.$message.success("上报成功");
            } else {
                this.$message.error("上报失败");
            }
        },
        querySearch(queryString, cb) {
            var restaurants = this.restaurants;
            var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
        // 调用 callback 返回建议列表的数据
        cb(results);
        },
        // 下拉菜单所需
        createFilter(queryString) {
            return (restaurant) => {
                return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
            };
        },        
        loadAll() {
        return [
          { "value": "发高烧", "address": "长宁区新渔路144号" },
          { "value": "头疼", "address": "上海市长宁区淞虹路661号" },
          { "value": "咳嗽", "address": "上海市普陀区真北路988号创邑金沙谷6号楼113" },
          { "value": "发现有密接人员", "address": "天山西路438号" },
         
        ];
      },
       handleSelect(item) {
        console.log(item);
      }
        
    },
     mounted() {
      this.restaurants = this.loadAll();
    }
}
</script>

<style lang="less" scoped>

.el-breadcrumb{
    margin-bottom: 15px;
    font-size: 12px;
}

.inline-input{
    width: 100%;
}

</style>
<template>
    <div>
        <h3>用户列表</h3>
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>事务处理</el-breadcrumb-item>
            <el-breadcrumb-item>隔离查询</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 用户列表主体部分 -->
        <el-card>
            <!-- 搜索区域 -->
            
            <!-- 绘制表格区 -->
            <el-table :data="userList" border stripe>
                <!-- 索引列 -->
                <el-table-column type="index"></el-table-column>
                <el-table-column label="用户名" prop="username"></el-table-column>
                <!-- <el-table-column label="密码" prop="password"></el-table-column> -->
                <el-table-column label="宿舍" prop="room"></el-table-column>
                <el-table-column label="权限" prop="admin"></el-table-column>
                <el-table-column label="学院" prop="college"></el-table-column>
                <el-table-column label="班级" prop="class1"></el-table-column>
                <el-table-column label="隔离房间" prop="geliroom"></el-table-column>
                <el-table-column label="是否隔离" prop="geli">
                    <!-- 作用域插槽 -->
                    <!-- <template slot-scope="scope">
                        <el-switch v-model="scope.row.geli"></el-switch>
                    </template> -->
                </el-table-column>
                
                <!-- <el-table-column label="隔离/解封">
                    <template slot-scope="scope">
                        <el-button type="warning" icon="el-icon-open" size="mini" @click="fanzhuan(scope.row.id)"></el-button>
                    </template>
                </el-table-column> -->
                <!-- 分页组件 -->
                
            </el-table>
            <!-- <div>
                    <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="queryInfo.pageNums"
                        :page-sizes="[1, 2, 5, 100]"
                        :page-size="queryInfo.pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total">
                    </el-pagination>
                </div> -->
        </el-card>

        <!-- 新增用户区域 -->
        <el-dialog title="新增用户" :visible.sync="addDialogVisible" width="50%" @close="addDialogClose">
            <el-form :model="addForm" :rules="addFormRules" ref="addFormRef" label-width="70px">
                <el-form-item label="用户名" prop="username">
                    <el-input v-model="addForm.username"></el-input>
                </el-form-item>
                <el-form-item label="密码" prop="password">
                    <el-input v-model="addForm.password"></el-input>
                </el-form-item>
                <el-form-item label="宿舍号" prop="room">
                    <el-input v-model="addForm.room"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog.footer">
                <el-button @click="addDialogVisible = false">取消</el-button>
                <el-button type="primary" @click="addUser">确定</el-button>
            </span>
        </el-dialog>

        <!-- 修改对话框 -->
        <el-dialog title="修改用户" :visible.sync="editDialogVisiable" width="50%" @close="editDialogClose">
            <el-form :model="editForm" :rules="editFormRules" ref="editFormRef" label-width="70px">
                <el-form-item label="用户名" prop="username" >
                    <el-input v-model="editForm.username" disabled></el-input>
                </el-form-item>
                <el-form-item label="密码" prop="password">
                    <el-input v-model="editForm.password"></el-input>
                </el-form-item>
                <el-form-item label="宿舍号" prop="room">
                    <el-input v-model="editForm.room"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog.footer">
                <el-button @click="editDialogVisiable = false">取消</el-button>
                <el-button type="primary" @click="editUserInfo">确定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
export default {
    created(){
        this.getUserList();
    },

    data(){
        return{
            //查询信息实体
            queryInfo:{
                query:"",
                pageNum:1,
                pageSize:500,
            },
            userList:[], //用户列表
            total:0,  //总记录数
            addDialogVisible:false, //对话框隐藏显示状态
            //添加表单信息
            addForm:{
                username:'',
                password:'',
                room:'',
            },
            //修改用户的信息
            editForm:{},
            //显示隐藏修改用户栏
            editDialogVisiable:false,
            //添加表单验证
            addFormRules: {
                username: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                    { min: 5, max: 8, message: '长度在 5 到 8 个字符', trigger: 'blur' }
                ],
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 5, max: 8, message: '长度在 5 到 8 个字符', trigger: 'blur' }
                ],
                room: [
                    { required: true, message: '请输入房间号', trigger: 'blur' },
                    { min: 3, max: 8, message: '长度在 3 到 8 个字符', trigger: 'blur' }
                ],
            },
            //修改表单验证
            editFormRules: {
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 5, max: 8, message: '长度在 5 到 8 个字符', trigger: 'blur' }
                ],
                room: [
                    { required: true, message: '请输入房间号', trigger: 'blur' },
                    { min: 3, max: 8, message: '长度在 3 到 8 个字符', trigger: 'blur' }
                ],
            },
        }
    },

    methods:{
        //获取所有用户
        async getUserList(){
            const {data:res} = await this.$http.get("geliuser",{params:this.queryInfo});
            this.userList=res.data;
            this.total=res.numbers;
        },
        //最大数
        handleSizeChange(newSize){
            this.queryInfo.pageSize=newSize;
            this.getUserList();
        },
        //pageNum触发动作
        handleCurrentChange(newPage){
            this.queryInfo.pageNum=newPage;;
            this.getUserList();
        },
        //监听添加用户
        addDialogClose(){
            this.$refs.addFormRef.resetFields();

        },
        addUser(){
            this.$refs.addFormRef.validate(async valid=>{
                if(!valid){
                    return;
                }
                const{data:res}=await this.$http.post("addUser",this.addForm);
                if(res!="success"){
                    return this.$message.error("操作失败！！！");
                }
                this.$message.success("操作成功！！！");
                this.addDialogVisible=false;
                this.getUserList();
            });
        },
        async deleteUser(id){
            const confirmRes = await this.$confirm('此操作将永久删除用户，是凑继续','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消删除");
            }
            const {data:res} = await this.$http.delete("deleteUser?id="+id);
            if (res!="success") {
                return this.$message.error("删除失败！！！");
            }
            this.$message.success("删除成功！！！");
            this.getUserList();
        },

        async fanzhuan(id){
            const confirmRes = await this.$confirm('此操作将解禁/隔离用户，是凑继续','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消删除");
            }
            const {data:res} = await this.$http.get("fanzhuan?id="+id);
            if (res!="success") {
                return this.$message.error("隔离/解禁失败！！！");
            }
            this.$message.success("隔离/解禁成功！！！");
            
            this.getUserList();
        },

        //显示和隐藏对话框
        async showEditDialog(id){
            const {data:res} = await this.$http.get("getupdate?id="+id);
            this.editForm=res;//查询用户信息反填到表单中
            
            this.editDialogVisiable=true;

        },
        //关闭窗口
        editDialogClose(){
            this.$refs.editFormRef.resetFields();
        },
        //确认修改
        editUserInfo(id){
            this.$refs.editFormRef.validate(async valid =>{
                if (!valid) {
                    return;
                }
                //发起修改请求
                const {data:res}= await this.$http.put("editUser",this.editForm);
                if (res!="success") {
                    return this.$message.error("修改失败！！！");
                }
                this.$message.success("修改成功！！！");
                this.getUserList();
            })
        },

    }
}
</script>

<style lang="less" scoped>

.el-breadcrumb{
    margin-bottom: 15px;
    font-size: 12px;
}

</style>
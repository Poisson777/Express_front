<template>
    <div>
        <h3>我的假条</h3>
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>事务处理</el-breadcrumb-item>
            <el-breadcrumb-item>我的假条</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 用户列表主体部分 -->
        <el-card>
            <!-- 搜索区域 -->
            
            <!-- 绘制表格区 -->
            <el-table :data="userList" border stripe>
                <!-- 索引列 -->
                <el-table-column type="index"></el-table-column>
                <el-table-column label="外出号" prop="tid"></el-table-column>
                <el-table-column label="学号" prop="id"></el-table-column>
                <el-table-column label="用户名" prop="username"></el-table-column>
                <el-table-column label="理由" prop="reason"></el-table-column>
                <el-table-column label="开始时间" prop="start"></el-table-column>
                <el-table-column label="结束时间" prop="finish"></el-table-column>
                <!-- <el-table-column label="是否隔离" prop="geli"> -->
                    <!-- 作用域插槽 -->
                    <!-- <template slot-scope="scope">
                        <el-switch v-model="scope.row.geli"></el-switch>
                    </template> -->
                <!-- </el-table-column> -->
                <el-table-column label="状态" prop="state"></el-table-column>
                <!-- 分页组件 -->
                
            </el-table>        
        </el-card>
    </div>
</template>

<script>
export default {
    created(){
        this.getUserList();
    },

    data(){
        return{
            //查询信息实体
            queryInfo:{
                query:"",
                pageNum:1,
                pageSize:5,
            },
            userList:[], //用户列表
            total:0,  //总记录数
            state:0,
            id:0,
        }
    },

    methods:{
        //获取所有用户
        async getUserList(){
            this.id=window.sessionStorage.getItem("id");
            const {data:res} = await this.$http.get("getTorderById?id="+this.id);
            //console.log(res);
            this.userList=res.data;
            // this.total=res.numbers;
        },
        //最大数
        handleSizeChange(newSize){
            this.queryInfo.pageSize=newSize;
            this.getUserList();
        },
        //pageNum触发动作
        handleCurrentChange(newPage){
            this.queryInfo.pageNum=newPage;;
            this.getUserList();
        },
        getOrder0(){
            this.state=0;
            console.log(0);
            this.getUserList();
        },
        getOrder1(){
            this.state=1;
            console.log(1);
            this.getUserList();
        },
        getOrder2(){
            this.state=2;
            console.log(2);
            this.getUserList();
        },
        async setOrder1(oid){
            const confirmRes = await this.$confirm('此操作将同意请假，是凑继续','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消删除");
            }
            const {data:res} = await this.$http.delete("agreeOrder?oid="+oid);
            if (res!="success") {
                return this.$message.error("删除失败！！！");
            }
            this.$message.success("已批准请假！！！");
            this.getUserList();
        },
        async setOrder2(oid){
            const confirmRes = await this.$confirm('此操作将拒绝请假，是凑继续','提示',{
                confirmButtonText:'确定',
                cancelButtonText:'取消',
                type:'warning'
            }).catch(err => err);
            if (confirmRes!='confirm') {
                return this.$message.Info("已取消删除");
            }
            const {data:res} = await this.$http.delete("refuseOrder?oid="+oid);
            if (res!="success") {
                return this.$message.error("删除失败！！！");
            }
            this.$message.success("已拒绝请假！！！");
            this.getUserList();
        }
    }
}
</script>

<style lang="less" scoped>

.el-breadcrumb{
    margin-bottom: 15px;
    font-size: 12px;
}

</style>
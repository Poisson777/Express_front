<template>
    <div>
        <h3>请假外出</h3>
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>事务处理</el-breadcrumb-item>
            <el-breadcrumb-item>外出申请</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 用户列表主体部分 -->
        <el-card>
            <el-form  ref="addFormRef" label-width="70px">
                <el-form-item label="学号" prop="id" >
                    <el-input v-model="order.id" disabled></el-input>
                </el-form-item>
                <el-form-item label="用户名" prop="username" >
                    <el-input v-model="order.username" disabled></el-input>
                </el-form-item>
               
                <el-form-item label="办公室" prop="room">
                    <el-input v-model="room" disabled></el-input>
                </el-form-item>
                <el-form-item label="身份" prop="shenfen">
                    <el-input v-model="shenfen" disabled></el-input>
                </el-form-item>
                <el-form-item label="学院" prop="college">
                    <el-input v-model="college" disabled></el-input>
                </el-form-item>
                <el-form-item label="地点" prop="place">
                    <el-input v-model="order.place"></el-input>
                </el-form-item>
                <el-form-item label="开始时间" prop="start">
                    <el-date-picker
                    class="dp1"
                    v-model="start"
                    type="date"
                    value-format="yyyy-MM-dd"
                    placeholder="选择日期">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="结束时间" prop="finish">
                    <el-date-picker
                    v-model="finish"
                    type="date"
                    value-format="yyyy-MM-dd"
                    placeholder="选择日期">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="请假理由" prop="reason">
                    <el-input v-model="order.reason"></el-input>
                </el-form-item>
            </el-form>
            <el-row :gutter="25">
                
                <!-- 搜索按钮 -->
                <el-col :span="4">
                    <el-button type="primary" @click="addUser">请假上报</el-button>  
                </el-col>              
            </el-row>
        </el-card>
    </div>
</template>

<script>
export default {
    created(){
        this.username= window.sessionStorage.getItem("username");
        this.password= window.sessionStorage.getItem("password");
        this.geli= window.sessionStorage.getItem("geli");
        this.room= window.sessionStorage.getItem("room");
        this.geliroom= window.sessionStorage.getItem("geliroom");
        this.college= window.sessionStorage.getItem("college");
        this.class1= window.sessionStorage.getItem("class1");
        this.id=window.sessionStorage.getItem("id");
        this.order.id=this.id;
        this.order.username=this.username;
        //console.log(this.username);
    },

    data(){
        return{
            //查询信息实体
            queryInfo:{
                query:"",
                pageNum:1,
                pageSize:500,
            },
            userList:[], //用户列表
            total:0, 
            tself:{}, //总记录数
            shenfen:"学生",
            username:"",
            password:"",
            room:"",
            geli:"",
            college:"",
            class1:"",
            id:0,
            start:"",
            finish:"",
            order:{
                place:"",
                username:"",
                id:0,
                reason:"",
                state:0,
                start:"",
                finish:"",
            }
        }
    },

    methods:{
        //获取所有用户
        async getUserList(){
            const {data:res} = await this.$http.get("alluser",{params:this.queryInfo});
            this.userList=res.data;
            this.total=res.numbers;
        },
        //最大数
        handleSizeChange(newSize){
            this.queryInfo.pageSize=newSize;
            this.getUserList();
        },
        //pageNum触发动作
        handleCurrentChange(newPage){
            this.queryInfo.pageNum=newPage;;
            this.getUserList();
        },
        insertOrder(){
            //console.log(this.order);
        },
        async addUser(){
            
            this.order.start=JSON.stringify(this.start);
            this.order.finish=JSON.stringify(this.finish);
            if(this.order.reason==""){
                this.$message.error("上报失败");
                return;
            }
            const{data:res}=await this.$http.post("addTorder",this.order);
            
            if (res=="success") {
                this.$message.success("上报成功");
            } else {
                this.$message.error("上报失败");
            }
        },
    }
}
</script>

<style lang="less" scoped>

.el-breadcrumb{
    margin-bottom: 15px;
    font-size: 12px;
}

.dp1{
    width: 100%;
}

</style>
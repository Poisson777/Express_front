<template>
    <!-- 引入contain布局 -->
    <el-container class="home-container">
        <el-header>
            <div>
                <img src="../assets/logo.jpg" alt/>
                <span>校园疫情管理平台-管理员</span>
            </div>
            
            <el-button type="info" @click="logout">安全退出</el-button>
        </el-header>
        <!-- 主体 -->
        <el-container>
            <!-- 侧边栏 -->
            <el-aside :width="isCollapse?'64px':'200px'">
                <div class="toggle-button" @click="toggleCollapase">|||</div>
                <el-menu
                background-color="#545c64"
                text-color="#fff"
                active-text-color="#409eff" unique-opened :collapse="isCollapse" :collapse-transition="false" :router="true" >
                <!-- 一级菜单 -->
                    <el-submenu index="1">
                        <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>学生管理</span>
                        </template>
                        <!-- 二级菜单                      -->
                        <el-menu-item index="user">学生信息管理</el-menu-item>
                        <el-menu-item index="order">请假审批</el-menu-item>                       
                        <el-menu-item index="incident">紧急处理</el-menu-item>
                        <el-menu-item index="utemlist">体温上报</el-menu-item>

                    </el-submenu>
                <!-- 一级菜单 -->
                    <el-submenu index="2">
                        <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>教师管理</span>
                        </template>
                        <!-- 二级菜单                      -->
                        <el-menu-item index="teacher">教师信息管理</el-menu-item>
                        <el-menu-item index="torder">外出请求</el-menu-item>  
                        <el-menu-item index="ttemlist">体温上报</el-menu-item> 

                    </el-submenu>      
                <!-- 一级菜单 -->
                    <el-submenu index="3">
                        <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>访客管理</span>
                        </template>
                        <!-- 二级菜单                      -->
                        <el-menu-item index="fangke">访客信息管理</el-menu-item>
                        <el-menu-item index="insertfangke">今日访客</el-menu-item>  
                        

                    </el-submenu>                
                    <el-menu-item index="tself">
                        <i class="el-icon-setting"></i>
                        <span slot="title">个人信息</span>
                    </el-menu-item>
                </el-menu>
            </el-aside>
            <!-- 主题内容 -->
            <el-main>
                <router-view ></router-view>
            </el-main>
        </el-container>
    </el-container>
</template>

<script>
export default {
    data(){
        return{
            isCollapse:false,
            date:"",
        }
    },
    methods:{
        logout(){
            window.sessionStorage.clear();  //清楚session中的内容，回到首页
            this.$router.push("/login");
        },
        xuesheng(){
            this.$router.push("/login");
        },
        toggleCollapase(){
            this.isCollapse=!this.isCollapse;
        }
    }
}
</script>

<style lang="less" scoped>
//布局器样式
.home-container{
    height: 100%;
}


//头部样式
.el-header{
    background-color: #373d41;
    display: flex;
    justify-content: space-between; //左右贴边
    padding-left: 0%; //左边界
    color: #fff;
    align-items: center;
    font-size: 20px;
    >div{
        display: flex;
        align-items: center; 
        span{
            margin-left: 15px;
        }
    }
}
//侧边栏样式
.el-aside{
    background-color: #333744;
    .el-menu{
        border-right: none;
    }
}
//主题样式
.el-main{
    background-color: #eaedf1;
}
img{
    width: 55px;
    height: 55px;
}

.toggle-button{
    background-color: #4A5064;
    font-size: 10px;
    line-height: 24px;
    color: #fff;
    text-align: center;
    letter-spacing: 0.2em;
    cursor: pointer; //经过的时候变成小手指
}

</style>